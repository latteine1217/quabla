# Project Instructions

Read [CLAUDE.md](CLAUDE.md) for repository conventions before changing files.

## Core Performance Objective

Quabla's core performance objective is to demonstrate a reproducible
end-to-end training advantage over both compiled PyTorch (`torch.compile`)
and compiled JAX (`jax.jit`) on representative PINN workloads, while
preserving numerical correctness and public API compatibility.

Prioritize measured training bottlenecks over expanding API coverage when
choosing performance work. Profile before selecting an optimization, and
validate it against the same workload and baselines afterward.

## Performance Acceptance

- Include nested input derivatives and parameter gradients in PINN tests.
  Compare resident training, including optimizer updates, separately from
  individual calls that return outputs to the host.
- Match hardware, dtype, model, initial parameters, data, optimizer, and
  numerical accuracy. Record framework and runtime versions, transfer and
  synchronization boundaries, and any unavoidable differences.
- Report first-call costs separately from warmed execution. Retain timing
  samples and repeat measurements enough to distinguish gains from noise.
- Verify loss, gradients, and training results before accepting speedups.
  Beating PyTorch eager alone does not meet the core performance objective.
- Scope every performance claim to its measured workloads and conditions.
  Report regressions and inconclusive results alongside improvements.

Before performance work or claims, read [docs/performance.md](docs/performance.md)
for the current comparison and its evidence. After each framework-comparison
experiment, update that file's current status, affected tables, interpretation,
limitations, and experiment-history index after verifying the outputs.
Retain failed or inconclusive experiments with their actual status; they
do not replace a completed comparison as evidence of an improvement.

Give each new run a distinct experiment ID and preserve its raw results,
configuration, versions, and source identity under `docs/benchmarks/`.
Replace current comparison rows only with directly comparable measurements;
keep different hardware, precision, or measurement contracts separate.
Preserve superseded evidence and link it from the history index. Keep
results and experiment history out of this protocol file.

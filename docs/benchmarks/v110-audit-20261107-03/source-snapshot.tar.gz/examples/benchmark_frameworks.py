"""Compare a nested-autodiff Poisson PINN on identical inputs.

Run each engine in a separate process. The timed contract includes returning
loss and every parameter gradient to host memory, but excludes optimizer updates.
Use --training to measure device-resident SGD in blocks of 100 updates.
The training metric includes one parameter readback per block, not per step.
"""

import argparse
import hashlib
import json
import math
import os
import platform
import statistics
import time
from pathlib import Path

import numpy as np


def problem(width, points, dtype):
    rng = np.random.default_rng(20261106)
    params = {
        "w1": rng.normal(0, 0.7, width).astype(dtype),
        "b1": rng.normal(0, 0.1, width).astype(dtype),
        "w2": rng.normal(0, 1 / math.sqrt(width), width).astype(dtype),
        "b2": np.array(0.05, dtype=dtype),
    }
    x = np.linspace(0.01, 0.99, points, dtype=dtype)
    return params, x


def reference(params, x):
    """Independent analytic input derivative and finite-difference weight gradient."""

    def loss(p):
        h = np.tanh(x[:, None] * p["w1"] + p["b1"])
        second = np.sum(-2 * h * (1 - h * h) * p["w1"] ** 2 * p["w2"], axis=1)
        xb = np.array([0.0, 1.0])
        boundary = (
            np.sum(np.tanh(xb[:, None] * p["w1"] + p["b1"]) * p["w2"], axis=1) + p["b2"]
        )
        return np.mean((second + math.pi**2 * np.sin(math.pi * x)) ** 2) + np.mean(
            boundary**2
        )

    p = {k: v.astype(np.float64) for k, v in params.items()}
    x = x.astype(np.float64)
    grads = {}
    for k, a in p.items():
        grad = np.empty_like(a)
        for index in np.ndindex(a.shape):
            original = a[index].item()
            delta = 1e-5 * max(1.0, abs(original))
            a[index] = original + delta
            plus = loss(p)
            a[index] = original - delta
            minus = loss(p)
            a[index] = original
            grad[index] = (plus - minus) / (2 * delta)
        grads[k] = grad
    return float(loss(p)), grads


def engine(name, device, dtype):
    if name == "quabla":
        import quabla as xp

        def convert(a):
            return xp.array(a, dtype=getattr(xp, dtype))

        grad, vmap = xp.grad, xp.vmap

        def compile_fn(fn):
            return xp.jit(fn, device=device)

        def host(a):
            return np.asarray(a.numpy())
    elif name == "jax":
        import jax
        import jax.numpy as xp

        jax.config.update("jax_enable_x64", True)
        target = jax.devices("gpu" if device == "cuda" else "cpu")[0]

        def convert(a):
            return jax.device_put(xp.asarray(a, dtype=getattr(xp, dtype)), target)

        grad, vmap = jax.grad, jax.vmap
        compile_fn = jax.jit

        def host(a):
            return np.asarray(a)
    else:
        import torch as xp

        xp.set_num_threads(1)
        xp.backends.cuda.matmul.allow_tf32 = False

        def convert(a):
            return xp.tensor(a, dtype=getattr(xp, dtype), device=device)

        def grad(fn, argnums=0):
            return xp.func.grad(fn, argnums=argnums)

        def vmap(fn, in_axes):
            return xp.vmap(fn, in_dims=in_axes)

        compile_fn = (
            (lambda fn: xp.compile(fn, fullgraph=True))
            if name == "torch-compile"
            else lambda fn: fn
        )

        def host(a):
            return a.detach().cpu().numpy()

    def u(p, x):
        return xp.sum(xp.tanh(x * p["w1"] + p["b1"]) * p["w2"]) + p["b2"]

    u_xx = vmap(grad(grad(u, argnums=1), argnums=1), in_axes=(None, 0))
    u_batch = vmap(u, in_axes=(None, 0))

    def loss(p, x, xb, forcing):
        residual = u_xx(p, x) + forcing
        boundary = u_batch(p, xb)
        return xp.mean(residual**2) + xp.mean(boundary**2)

    if name == "quabla":
        fn = xp.value_and_grad(loss)
    elif name == "jax":
        fn = jax.value_and_grad(loss)
    else:
        grad_and_value = xp.func.grad_and_value(loss)

        def fn(*args):
            grads, value = grad_and_value(*args)
            return value, grads

    version = jax.__version__ if name == "jax" else xp.__version__

    def materialize(result):
        if name == "jax":
            result = jax.device_get(result)
        value, grads = result
        return float(host(value)), {k: host(v) for k, v in grads.items()}

    def training(parameters, data):
        if name == "quabla":
            trainer = xp.optim.Trainer(
                loss,
                parameters,
                xp.optim.SGD(learning_rate=0.001),
                *data,
                device=device,
            )

            def snapshot():
                return {k: host(v) for k, v in trainer.params.items()}

            def current_loss():
                return float(host(trainer.loss()))

            return trainer.step, snapshot, current_loss

        def update(parameters, *data):
            _, gradients = fn(parameters, *data)
            return {k: v - 0.001 * gradients[k] for k, v in parameters.items()}

        update = compile_fn(update)
        state = parameters

        def step():
            nonlocal state
            state = update(state, *data)

        def snapshot():
            return materialize((state["b2"], state))[1]

        def current_loss():
            return materialize(fn(state, *data))[0]

        return step, snapshot, current_loss

    return compile_fn(fn), convert, materialize, version, training


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--engine",
        choices=["quabla", "jax", "torch-eager", "torch-compile"],
        required=True,
    )
    parser.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    parser.add_argument("--dtype", choices=["float32", "float64"], default="float64")
    parser.add_argument("--width", type=int, default=16)
    parser.add_argument("--points", type=int, default=256)
    parser.add_argument("--samples", type=int, default=7)
    parser.add_argument("--training", action="store_true")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    params, x = problem(args.width, args.points, args.dtype)
    expected_loss, expected_grad = reference(params, x)
    fn, convert, materialize, version, training = engine(
        args.engine, args.device, args.dtype
    )
    p = {k: convert(a) for k, a in params.items()}
    inputs = (
        p,
        convert(x),
        convert(np.array([0.0, 1.0], dtype=args.dtype)),
        convert((math.pi**2 * np.sin(math.pi * x)).astype(args.dtype)),
    )

    def call():
        return materialize(fn(*inputs))

    started = time.perf_counter()
    actual_loss, actual_grad = call()
    first_ms = (time.perf_counter() - started) * 1000
    tolerance = 1e-4 if args.dtype == "float32" else 1e-7
    np.testing.assert_allclose(
        actual_loss, expected_loss, atol=tolerance, rtol=tolerance
    )
    for key in params:
        np.testing.assert_allclose(
            actual_grad[key], expected_grad[key], atol=tolerance, rtol=tolerance
        )
    training_result = {}
    if args.training:
        step, snapshot, current_loss = training(p, inputs[1:])
        started = time.perf_counter()
        step()
        first_params = snapshot()
        training_first_step_ms = (time.perf_counter() - started) * 1000
        for key in params:
            np.testing.assert_allclose(
                first_params[key],
                params[key] - 0.001 * expected_grad[key],
                atol=tolerance,
                rtol=tolerance,
            )
        for _ in range(5):
            step()
        snapshot()
        repeats = 100
        samples = []
        for _ in range(args.samples):
            started = time.perf_counter()
            for _ in range(repeats):
                step()
            final_params = snapshot()
            samples.append((time.perf_counter() - started) * 1000 / repeats)
        final_loss = current_loss()
        assert math.isfinite(final_loss) and final_loss < actual_loss
        training_result = {
            "training_first_step_ms": training_first_step_ms,
            "training_steps": 6 + args.samples * repeats,
            "final_loss": final_loss,
            "final_parameters": {k: v.tolist() for k, v in final_params.items()},
            "learning_rate": 0.001,
        }
    else:
        for _ in range(5):
            call()
        started = time.perf_counter()
        for _ in range(5):
            call()
        estimate = (time.perf_counter() - started) / 5
        repeats = max(5, min(2000, math.ceil(0.1 / estimate)))
        samples = []
        for _ in range(args.samples):
            started = time.perf_counter()
            for _ in range(repeats):
                call()
            samples.append((time.perf_counter() - started) * 1000 / repeats)
    result = {
        "status": "passed",
        "engine": args.engine,
        "version": version,
        "device": args.device,
        "dtype": args.dtype,
        "width": args.width,
        "points": args.points,
        "seed": 20261106,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "first_call_ms": first_ms,
        "median_ms": statistics.median(samples),
        "samples_ms": samples,
        "calls_per_sample": repeats,
        "loss": actual_loss,
        "reference_loss": expected_loss,
        "loss_abs_error": abs(actual_loss - expected_loss),
        "gradient_max_abs_error": max(
            float(np.max(np.abs(actual_grad[k] - expected_grad[k]))) for k in params
        ),
        "gradients": {k: v.tolist() for k, v in actual_grad.items()},
        "contract": (
            "device-resident SGD, parameters materialized every 100 steps"
            if args.training
            else "fixed-parameter loss and gradient, all outputs materialized on host; no optimizer"
        ),
        **training_result,
        "input_sha256": hashlib.sha256(
            b"".join(a.tobytes() for a in [*params.values(), x])
        ).hexdigest(),
        "thread_environment": {
            k: os.environ.get(k)
            for k in [
                "OMP_NUM_THREADS",
                "MKL_NUM_THREADS",
                "OPENBLAS_NUM_THREADS",
                "XLA_FLAGS",
            ]
        },
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                k: v
                for k, v in result.items()
                if k not in ["gradients", "thread_environment", "final_parameters"]
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
